from django.urls import include, path
from rest_framework.routers import DefaultRouter
from .views import (
    CategoryViewSet,
    DepartmentViewSet,
    GrievanceViewSet,
    LoginEmailOtpView,
    VerifyEmailOtpView,
)

router = DefaultRouter()
router.register("grievances", GrievanceViewSet, basename="grievances")
router.register("categories", CategoryViewSet, basename="categories")
router.register("departments", DepartmentViewSet, basename="departments")

urlpatterns = [
    path("auth/login/", LoginEmailOtpView.as_view(), name="auth-login"),
    path("auth/verify-otp/", VerifyEmailOtpView.as_view(), name="auth-verify-otp"),
    path("", include(router.urls)),
]
