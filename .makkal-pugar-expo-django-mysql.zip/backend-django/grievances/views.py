from django.utils import timezone
from rest_framework import permissions, status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken
from .models import Category, Department, EmailOtpToken, Grievance, GrievanceTimeline, PortalUser
from .otp_service import dispatch_email_otp
from .serializers import CategorySerializer, DepartmentSerializer, GrievanceSerializer, PortalUserSerializer


class LoginEmailOtpView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        identifier = request.data.get("identifier", "").strip().lower()
        password = request.data.get("password", "")
        role = request.data.get("role", "citizen")
        user = PortalUser.objects.filter(email__iexact=identifier, role=role).first()
        if not user or not user.check_password(password):
            return Response({"error": "Invalid credentials"}, status=status.HTTP_401_UNAUTHORIZED)
        if user.account_status != "active":
            return Response({"error": f"Account status is {user.account_status}"}, status=status.HTTP_403_FORBIDDEN)
        dispatch_email_otp(user.email, role, "login")
        return Response({"otp_required": True, "email": user.email, "role": role})


class VerifyEmailOtpView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        email = request.data.get("email", "").strip().lower()
        role = request.data.get("role", "citizen")
        code = request.data.get("code", "").strip()
        otp = EmailOtpToken.objects.filter(email=email, role=role, consumed=False).order_by("-id").first()
        if not otp or otp.attempts >= 5 or timezone.now() > otp.expires_at:
            return Response({"error": "OTP expired or locked"}, status=status.HTTP_400_BAD_REQUEST)
        if otp.code != code:
            otp.attempts += 1
            otp.save()
            return Response({"error": "Incorrect OTP"}, status=status.HTTP_400_BAD_REQUEST)
        otp.consumed = True
        otp.save()
        user = PortalUser.objects.get(email__iexact=email, role=role)
        refresh = RefreshToken.for_user(user)
        return Response({
            "access": str(refresh.access_token),
            "refresh": str(refresh),
            "user": PortalUserSerializer(user).data,
        })


class GrievanceViewSet(viewsets.ModelViewSet):
    serializer_class = GrievanceSerializer

    def get_queryset(self):
        user = self.request.user
        if user.role == "citizen":
            return Grievance.objects.filter(citizen=user).order_by("-id")
        return Grievance.objects.all().order_by("-id")

    @action(detail=True, methods=["patch"])
    def update_status(self, request, pk=None):
        if request.user.role not in ("officer", "admin"):
            return Response({"error": "Forbidden"}, status=status.HTTP_403_FORBIDDEN)
        grievance = self.get_object()
        next_status = request.data.get("status")
        remarks = request.data.get("remarks", "")
        grievance.status = next_status
        grievance.field_notes = remarks or grievance.field_notes
        grievance.save()
        GrievanceTimeline.objects.create(
            grievance=grievance,
            step_key=next_status,
            title_ta=next_status,
            title_en=next_status.replace("_", " ").title(),
            remarks=remarks,
            actor_name=request.user.full_name,
        )
        return Response(GrievanceSerializer(grievance).data)


class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer


class DepartmentViewSet(viewsets.ModelViewSet):
    queryset = Department.objects.all()
    serializer_class = DepartmentSerializer
