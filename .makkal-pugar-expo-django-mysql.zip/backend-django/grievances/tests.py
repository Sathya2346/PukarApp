from django.test import TestCase
from rest_framework.test import APIClient
from .models import EmailOtpToken, PortalUser
from .otp_service import dispatch_email_otp


class EmailOtpAuthTests(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.user = PortalUser.objects.create_user(
            username="citizen_test",
            email="citizen@example.com",
            password="Password@123",
            full_name="Test Citizen",
            role="citizen",
            account_status="active",
        )

    def test_login_issues_email_otp_and_verifies(self):
        res = self.client.post("/api/auth/login/", {
            "identifier": "citizen@example.com",
            "password": "Password@123",
            "role": "citizen",
        })
        self.assertEqual(res.status_code, 200)
        otp = EmailOtpToken.objects.get(email="citizen@example.com", consumed=False)
        verify = self.client.post("/api/auth/verify-otp/", {
            "email": "citizen@example.com",
            "role": "citizen",
            "code": otp.code,
        })
        self.assertEqual(verify.status_code, 200)
        self.assertIn("access", verify.data)

    def test_wrong_otp_increments_attempts_and_rejects(self):
        dispatch_email_otp("citizen@example.com", "citizen")
        verify = self.client.post("/api/auth/verify-otp/", {
            "email": "citizen@example.com",
            "role": "citizen",
            "code": "000000",
        })
        self.assertEqual(verify.status_code, 400)
