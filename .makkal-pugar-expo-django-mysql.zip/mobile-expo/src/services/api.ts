import * as SecureStore from "expo-secure-store";

const BASE_URL = process.env.EXPO_PUBLIC_API_URL || "http://10.0.2.2:8000/api";

async function request(path: string, options: RequestInit = {}) {
  const token = await SecureStore.getItemAsync("access_token");
  const res = await fetch(`${BASE_URL}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {}),
    },
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "API request failed");
  return data;
}

export const mobileApi = {
  loginWithEmailOtp: (identifier: string, password: string, role: string) =>
    request("/auth/login/", {
      method: "POST",
      body: JSON.stringify({ identifier, password, role }),
    }),
  verifyEmailOtp: (email: string, role: string, code: string) =>
    request("/auth/verify-otp/", {
      method: "POST",
      body: JSON.stringify({ email, role, code }),
    }),
  listGrievances: () => request("/grievances/"),
  createGrievance: (payload: Record<string, unknown>) =>
    request("/grievances/", { method: "POST", body: JSON.stringify(payload) }),
  updateGrievanceStatus: (id: number, status: string, remarks: string) =>
    request(`/grievances/${id}/update_status/`, {
      method: "PATCH",
      body: JSON.stringify({ status, remarks }),
    }),
};
